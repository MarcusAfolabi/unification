<?php $__env->startSection('title', 'All Post'); ?>
<?php $__env->startSection('description', 'This is all Post'); ?>
<?php $__env->startSection('keywords', 'blog, posts, bloging, wordpress'); ?>
<?php $__env->startSection('canonical', 'https://cnsunification.org/posts'); ?>

<?php $__env->startSection('main'); ?>
<div class="main_content">
<div class="mcontainer">
<?php if(auth()->guard()->check()): ?>
<?php if(auth()->user()->isAdmin()): ?>
        <div class="flex justify-between items-center relative md:mb-4 mb-3">
            <div class="flex-1">
                <h5 class="text-1xl font-semibold">
                    <a href="<?php echo e(route('posts.create')); ?>"><i class="icon-material-outline-add"></i> New Post </a>
                </h5>
            </div>
        </div>
        <?php if(session('status')): ?>
        <p class="bg-green-500 text-white text-center border p-4 relative rounded-md uk-alert">
            <?php echo e(session('status')); ?></p>
        <?php endif; ?>
        <div class="card">
            <div class="header-search-icon" uk-toggle="target: #wrapper ; cls: show-searchbox"> </div>
            <div class="header_search"><i class="uil-search-alt"></i>
                <form action="">
                    <input type="text" class="form-control" name="search"
                        placeholder="Search your Post, Content and more.." autocomplete="off">
                </form>
            </div>
            <hr>
            <br>
            <?php if($posts->count() > 0): ?>
            <div class="flex flex-col">
                <div class="overflow-x-auto sm:-mx-6 lg:-mx-8">
                    <div class="py-2 inline-block min-w-full sm:px-6 lg:px-8">
                        <div class="overflow-x-auto">
                            <table class="min-w-full">
                                <thead class="border-b bg-gray-50">
                                    <tr>
                                        <th scope="col" class="text-sm font-medium text-gray-900 px-6 py-4 text-left">
                                            S/No</th>
                                        <th scope="col" class="text-sm font-medium text-gray-900 px-6 py-4 text-left">
                                            Image</th>
                                        <th scope="col" class="text-sm font-medium text-gray-900 px-6 py-4 text-left">
                                            Title</th>
                                        <th scope="col" class="text-sm font-medium text-gray-900 px-6 py-4 text-left">
                                            Category</th>
                                        <th scope="col" class="text-sm font-medium text-gray-900 px-6 py-4 text-left">
                                            Creator</th>
                                        <th scope="col" class="text-sm font-medium text-gray-900 px-6 py-4 text-left">
                                            Date</th>
                                        <th scope="col" class="text-sm font-medium text-gray-900 px-6 py-4 text-left">
                                            Edit</th>
                                        <th scope="col" class="text-sm font-medium text-gray-900 px-6 py-4 text-left">
                                            Delete</th>
                                        <th scope="col" class="text-sm font-medium text-gray-900 px-6 py-4 text-left">
                                            Status</th>
                                        <th scope="col" class="text-sm font-medium text-gray-900 px-6 py-4 text-left">
                                            Views</th>
                                    </tr>
                                </thead>

                                <tbody>
                                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="border-b">
                                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900"><?php echo e(++$key); ?></td>
                                        <th class="text-sm text-gray-900 font-light px-6 py-4 whitespace-nowrap"><a
                                                href="<?php echo e(asset($post->image)); ?>"> <img src="<?php echo e(asset($post->image)); ?>"
                                                    alt="<?php echo e($post->postTitle); ?>" class="rounded-lg"
                                                    style="max-height: 50px; max-width:50px" srcset=""></a></th>
                                        <td class="text-sm text-gray-900 font-light px-6 py-4 whitespace-nowrap"><a
                                                href="<?php echo e(route('posts.show', $post)); ?>"><?php echo e($post->postTitle); ?></a>
                                        </td>
                                        <td class="text-sm text-gray-900 font-light px-6 py-4 whitespace-nowrap"><?php echo e($post->postCategories); ?></td>
                                        <td class="text-sm text-gray-900 font-light px-6 py-4 whitespace-nowrap"> <a
                                                href="<?php echo e(route('user.index', $post->user->id)); ?>">
                                                <?php echo e($post->user->name); ?> </a></td>
                                        <td class="text-sm text-gray-900 font-light px-6 py-4 whitespace-nowrap"> <?php echo e($post->created_at->diffForHumans()); ?></td>

                                        <td class="text-sm text-gray-900 font-light px-6 py-4 whitespace-nowrap"> <a
                                                href="<?php echo e(route('posts.edit', $post)); ?>"> <span
                                                    class="icon-feather-edit "></span></a></td>
                                        <td class="text-sm text-gray-900 font-light px-6 py-4 whitespace-nowrap">
                                            <form action="<?php echo e(route('posts.destroy', $post)); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('delete'); ?>
                                                <button type="submit"
                                                    onclick="return confirm('Hey, Are you sure about this?');">
                                                    <span class="icon-feather-trash-2"></span> </button>

                                            </form>
                                        </td>
                                        <td class="text-sm text-gray-900 font-light px-6 py-4 whitespace-nowrap">
                                            <script
                                                src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
                                                integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
                                                crossorigin="anonymous"></script>

                                            <div class="switches-list">
                                                <div class="switch-container">
                                                    <?php if($post->status =='1'): ?>
                                                    <label class="switch"><a href="<?php echo e(url('/status', $post)); ?>"><input
                                                                type="checkbox" checked>
                                                            <span class="switch-button"></span>Active</a> </label>
                                                    <?php else: ?>
                                                    <label class="switch"> <a href="<?php echo e(url('/status', $post)); ?>"><input
                                                                type="checkbox">
                                                            <span class="switch-button"></span>InActive </a></label>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </td>
                                        <td class="text-sm text-gray-900 font-light px-6 py-4 whitespace-nowrap">
                                            <?php echo e($post->views); ?> read </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <?php else: ?>
                        <p class="text-center text-opacity-75"> <span class="icon-material-outline-user"></span>
                            Sorry, nothing to show</p>
                        <?php endif; ?>
                    </div>
                    <?php echo e($posts->links()); ?>


                </div>
            </div>
        </div>
        <?php elseif(!auth()->user()->isAdmin()): ?>
        <div class="lg:flex  lg:space-x-12">

            <div class="lg:w-3/4">

                <div class="flex justify-between items-center relative md:mb-4 mb-3">
                    <div class="flex-1">
                        <h2 class="text-2xl font-semibold"> My Post </h2>
                        
                    </div>
                    <a href="<?php echo e(route('posts.create')); ?>"
                        class="flex items-center justify-center h-10 w-10 z-10 rounded-full bg-blue-600 text-white absolute right-0"
                        data-tippy-placement="left" title="Create New Article">
                        <svg class="w-6 h-6" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                            <path fill-rule="evenodd"
                                d="M10 5a1 1 0 011 1v3h3a1 1 0 110 2h-3v3a1 1 0 11-2 0v-3H6a1 1 0 110-2h3V6a1 1 0 011-1z"
                                clip-rule="evenodd"></path>
                        </svg>
                    </a>
                </div>

                <div class="card divide-y divide-gray-100 px-4">
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="lg:flex lg:space-x-6 py-5">
                        <a href="<?php echo e(route('posts.show', $post)); ?>">
                            <div class="lg:w-60 w-full h-40 overflow-hidden rounded-lg relative shadow-sm">
                                <img src="<?php echo e(asset($post->image)); ?>" alt="<?php echo e($post->postTitle); ?>"
                                    class="w-full h-full absolute inset-0 object-cover">
                                <div
                                    class="absolute bg-blue-100 font-semibold px-2.5 py-1 rounded-full text-blue-500 text-xs top-2.5 left-2.5">
                                    <?php echo e($post->postCategories); ?>

                                </div>
                            </div>
                        </a>
                        <div class="flex-1 lg:pt-0 pt-4">

                            <a href="<?php echo e(route('posts.show', $post)); ?>" class="text-xl font-semibold line-clamp-2">
                                <?php echo e($post->postTitle); ?></a>
                            
                            <div class="border-b dark:border-gray-700 leading-6 line-clamp-2 mt-5">

                                <?php echo $post->fullDescription; ?>

                            </div>
                            <div class="flex items-center pt-3">
                                <div class="flex items-center"> <a href="<?php echo e(route('posts.edit', $post)); ?>"> <span
                                            class="icon-feather-edit "></span></a></td>
                                </div>
                                <div class="flex items-center mx-4">

                                    <form action="<?php echo e(route('posts.destroy', $post)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('delete'); ?>
                                        <button type="submit"
                                            onclick="return confirm('Hey, Are you sure about this?');">
                                            <span class="icon-feather-trash-2"></span> </button>

                                    </form>
                                </div>
                                <div class="flex items-center">
                                    <?php echo e($post->created_at->diffForHumans()); ?> </div>
                            </div>

                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                </div>
                <br>
                <?php echo e($posts->links()); ?>



            </div>
            <div class="lg:w-1/4 w-full flex-shrink-0">

                <div uk-sticky="offset:100" class="uk-sticky">

                    <h2 class="text-lg font-semibold mb-3"> Similar Posts </h2>
                    <ul>
                        <?php $__currentLoopData = $sideposts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sidepost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <a href="<?php echo e(route('posts.show', $sidepost)); ?>"
                                class="hover:bg-gray-100 rounded-md p-2 -mx-2 block">
                                <h3 class="font-medium line-clamp-2"> <?php echo e($sidepost->postTitle); ?> </h3>
                                <div class="flex items-center my-auto text-xs space-x-1.5">
                                    <div> <?php echo e($sidepost->created_at->diffForHumans()); ?></div>
                                    <div class="pb-1"> . </div>
                                    <ion-icon name="chatbox-ellipses-outline"></ion-icon>
                                    <div> <?php echo e($sidepost->views); ?> views</div>
                                </div>
                            </a>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    </ul>
                    <br>

                    <h4 class="text-lg font-semibold mb-3"> Recommended Products </h4>

                    <div class="bg-white mb-5 px-4 py-3 rounded-md shadow">
                        
                        <?php $__currentLoopData = $sideproducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sideproduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('products.show', $sideproduct)); ?>">
                            <div class="-mx-2 duration-300 flex hover:bg-gray-50 px-2 py-2 rounded-md">
                                <img src="<?php echo e(asset($sideproduct->image)); ?>" class="w-9 h-9 mr-3" alt="">
                                <p class="line-clamp-1 mt-2 leading-6"> <strong> <?php echo e($sideproduct->name); ?> </strong> for
                                    <strong> <?php echo e($sideproduct->currency); ?><?php echo e(number_format($sideproduct->price)); ?>

                                    </strong>

                                </p>
                            </div>
                        </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                    <a href="<?php echo e(route('products.index')); ?>" class="hover:text-blue-600 hover:underline"> See All </a>


                </div>
            </div>
        </div>
        <?php endif; ?>
        <?php endif; ?>
    </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\unification\resources\views/posts/index.blade.php ENDPATH**/ ?>