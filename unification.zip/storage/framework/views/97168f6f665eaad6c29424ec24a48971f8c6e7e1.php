<?php $__env->startSection('title', 'All Prayers'); ?>
<?php $__env->startSection('description', 'This is all prayer supplications'); ?>
<?php $__env->startSection('keywords', 'praying hands, answering prayer, pray, bible'); ?>
<?php $__env->startSection('canonical', 'https://cnsunification.org/prayers'); ?>

<?php $__env->startSection('main'); ?>
<!--  breadcrumb -->

<div class="main_content">
    <div class="mcontainer">
        <?php if(auth()->guard()->check()): ?>
        <?php if(auth()->user()->isAdmin()): ?>
        <div class="flex justify-between items-center relative md:mb-4 mb-3">
            <div class="flex-1">
                <h5 class="text-1xl font-semibold">
                    <a href="<?php echo e(route('prayers.create')); ?>"><i class="icon-material-outline-add"></i> New Prayer </a>
                </h5>
            </div>
        </div>
        <?php if(session('status')): ?>
        <p class="bg-green-500 text-white text-center border p-4 relative rounded-md uk-alert">
            <?php echo e(session('status')); ?></p>
        <?php endif; ?>
        <div class="card">
            <div class="header-search-icon" uk-toggle="target: #wrapper ; cls: show-searchbox"> </div>
            <div class="header_search"><i class="uil-search-alt"></i>
                <form action="">
                    <input type="text" class="form-control" name="prayers"
                        placeholder="Search for Bible Study, Prayer and more.." autocomplete="off">
                </form>
            </div>
            <hr>
            <br>
            <?php if($prayers->count() > 0): ?>
            <div class="flex flex-col">
                <div class="overflow-x-auto sm:-mx-6 lg:-mx-8">
                    <div class="py-2 inline-block min-w-full sm:px-6 lg:px-8">
                        <div class="overflow-x-auto">
                            <table class="min-w-full">
                                <thead class="border-b bg-gray-50">
                                    <tr>
                                        <th scope="col" class="text-sm font-medium text-gray-900 px-6 py-4 text-left">
                                            S/No</th>
                                        <th scope="col" class="text-sm font-medium text-gray-900 px-6 py-4 text-left">
                                            Title</th>
                                        <th scope="col" class="text-sm font-medium text-gray-900 px-6 py-4 text-left">
                                            Author</th>
                                        <th scope="col" class="text-sm font-medium text-gray-900 px-6 py-4 text-left">
                                            Publication</th>
                                        <th scope="col" class="text-sm font-medium text-gray-900 px-6 py-4 text-left">
                                            Category</th>
                                        <th scope="col" class="text-sm font-medium text-gray-900 px-6 py-4 text-left">
                                            Creator</th>
                                        <th scope="col" class="text-sm font-medium text-gray-900 px-6 py-4 text-left">
                                            Date</th>
                                        <th scope="col" class="text-sm font-medium text-gray-900 px-6 py-4 text-left">
                                            Edit</th>
                                        <th scope="col" class="text-sm font-medium text-gray-900 px-6 py-4 text-left">
                                            Status</th>
                                        <th scope="col" class="text-sm font-medium text-gray-900 px-6 py-4 text-left">
                                            Views</th>
                                        <th scope="col" class="text-sm font-medium text-gray-900 px-6 py-4 text-left">
                                            Delete</th>
                                    </tr>
                                </thead>

                                <tbody>
                                    <?php $__currentLoopData = $prayers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $prayer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="border-b">
                                        <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900"><?php echo e(++$key); ?></td>
                                        <td class="text-sm text-gray-900 font-light px-6 py-4 whitespace-nowrap"> <a
                                                href="<?php echo e(route('prayers.show', $prayer)); ?>" target="_blank">
                                                <?php echo e($prayer->title); ?> </a>
                                        </td>
                                        <td class="text-sm text-gray-900 font-light px-6 py-4 whitespace-nowrap"><?php echo e($prayer->author); ?></td>
                                        <td class="text-sm text-gray-900 font-light px-6 py-4 whitespace-nowrap"><?php echo e(date('l-d-M-Y', strtotime($prayer->publication))); ?></td>
                                        <td class="text-sm text-gray-900 font-light px-6 py-4 whitespace-nowrap"> <?php echo e($prayer->category); ?></td>
                                        <td class="text-sm text-gray-900 font-light px-6 py-4 whitespace-nowrap"> <?php echo e($prayer->user->name); ?> </td>
                                        <td class="text-sm text-gray-900 font-light px-6 py-4 whitespace-nowrap"><?php echo e($prayer->created_at->diffForHumans()); ?></td>
                                        <td class="text-sm text-gray-900 font-light px-6 py-4 whitespace-nowrap"> <a
                                                href="<?php echo e(route('prayers.edit', $prayer)); ?>"> <span
                                                    class="icon-feather-edit "></span></a></td>
                                        <td class="text-sm text-gray-900 font-light px-6 py-4 whitespace-nowrap">
                                            <script
                                                src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
                                                integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
                                                crossorigin="anonymous"></script>

                                            <div class="switches-list">
                                                <div class="switch-container">
                                                    <?php if($prayer->status =='1'): ?>
                                                    <label class="switch"><a href="<?php echo e(url('/status', $prayer)); ?>"><input
                                                                type="checkbox" checked>
                                                            <span class="switch-button"></span>Active</a> </label>
                                                    <?php else: ?>
                                                    <label class="switch"> <a
                                                            href="<?php echo e(url('/status', $prayer)); ?>"><input type="checkbox">
                                                            <span class="switch-button"></span>InActive </a></label>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </td>
                                        <td class="text-sm text-gray-900 font-light px-6 py-4 whitespace-nowrap"> <?php echo e($prayer->views); ?> prayed</td>
                                        <td class="text-sm text-gray-900 font-light px-6 py-4 whitespace-nowrap">
                                            <form action="<?php echo e(route('prayers.destroy', $prayer)); ?>" method="POST">
                                                <?php echo method_field('delete'); ?>
                                                <?php echo csrf_field(); ?>
                                                <button type="submit"
                                                    onclick="return confirm('Hey, Are you sure about this?');">
                                                    <span class="icon-feather-trash-2"></span> </button>

                                            </form>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <?php else: ?>
                        <p class="text-center text-opacity-75"> Nothing Here!</p>
                        <?php endif; ?>
                    </div>
                    <?php echo e($prayers->links()); ?>


                </div>
            </div>
        </div>
    </div>
    <?php elseif(!auth()->user()->isAdmin()): ?>
    <div class="lg:flex lg:space-x-10">

        <div class="lg:w-2/3">

            <!-- Clips -->

            <div class="my-5 flex justify-between pb-3">
                <h2 class="text-2xl font-semibold"> My Bible Study and Daily Prayers </h2>
            </div>
            <div class="flex justify-between items-center relative md:mb-4 mb-3">

                <a href="<?php echo e(route('prayers.create')); ?>"
                    class="flex items-center justify-center h-10 w-10 z-10 rounded-full bg-blue-600 text-white absolute right-0"
                    data-tippy-placement="left" title="Create New prayer">
                    <svg class="w-6 h-6" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                        <path fill-rule="evenodd"
                            d="M10 5a1 1 0 011 1v3h3a1 1 0 110 2h-3v3a1 1 0 11-2 0v-3H6a1 1 0 110-2h3V6a1 1 0 011-1z"
                            clip-rule="evenodd"></path>
                    </svg>
                </a>
            </div>

            <?php if($prayers->count() > 0): ?>
            <div class="divide-y -mt-3 card px-5 py-2 ">

                <?php $__currentLoopData = $prayers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prayer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(auth()->user()->id === $prayer->user->id): ?>
                <div class="flex sm:flex-row flex-col sm:space-x-4 py-4 relative w-full">

                    <div class="flex-1 relative md:mt-0 mt-4">
                        
                        <a href="<?php echo e(route('prayers.show', $prayer)); ?>" class="text-xl font-semibold leading-6"><?php echo e($prayer->title); ?></a>
                        <div class="font-semibold mt-2"> Minister: <?php echo e($prayer->author); ?> </div>
                        <div class="flex space-x-2 items-center text-sm pt-1">
                            <div> <?php echo e($prayer->created_at->diffForHumans()); ?></div>
                            <div>·</div>
                            <a href="<?php echo e(route('prayers.edit', $prayer)); ?>"> <span class="icon-feather-edit "></span>
                                Edit</a>
                            <div>·</div>
                            <div>
                                <form action="<?php echo e(route('prayers.destroy', $prayer)); ?>" method="POST">
                                    <?php echo method_field('delete'); ?>
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" onclick="return confirm('Hey, Are you sure about this?');">
                                        <span class="icon-feather-trash-2"></span> Delete</button>

                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
            <?php else: ?>
            <p class="text-center text-opacity-75"> Nothing Here!</p>
            <?php endif; ?>
        </div>

        <!-- Sidebar -->
        <div class="lg:w-1/3 w-full">
            <div uk-sticky="media @m ; offset:80 ; bottom : true" class="card">


                <div class="border-b flex items-center justify-between  p-4">
                    <div>
                        <h2 class="text-lg font-semibold">Recent prayer</h2>
                    </div>
                </div>

                <div class="p-3">

                    <?php $__currentLoopData = $recentprayers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prayer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="flex items-center space-x-4 rounded-md -mx-2 p-2 hover:bg-gray-50">
                        <a href="<?php echo e(route('prayers.show', $prayer)); ?>" iv
                            class="w-12 h-12 flex-shrink-0 overflow-hidden rounded-full relative">
                            <img src="<?php echo e(asset('assets/images/icons/bible-icon.png')); ?>" class="absolute w-full h-full inset-0 "
                                alt="<?php echo e($prayer->title); ?>">
                        </a>
                        <div class="flex-1">
                            <a href="<?php echo e(route('prayers.show', $prayer)); ?>"
                                class="text-base font-semibold capitalize line-clamp-1 mt-1">
                                <?php echo e($prayer->title); ?>

                            </a>
                            <div class="text-sm text-gray-500 mt-0.5"> <?php echo e($prayer->views); ?> Praying</div>
                        </div>

                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </div>

                <a href="<?php echo e(route('prayers.index')); ?>" class="border-t block text-center py-2"> See all </a>

            </div>
        </div>


    </div>
    <?php endif; ?>
    <?php endif; ?>

    <?php if(auth()->guard()->guest()): ?>
    <div class="lg:flex lg:space-x-10">

        <div class="lg:w-2/3">

            <!-- Clips -->

            <div class="my-5 flex justify-between pb-3">
                <h2 class="text-2xl font-semibold"> Top prayers </h2>
            </div>

            <div class="divide-y -mt-3 card px-5 py-2 ">

                <?php $__currentLoopData = $prayers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prayer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="flex sm:flex-row flex-col sm:space-x-4 py-4 relative w-full">
                    
                    <div class="flex-1 relative md:mt-0 mt-4">
                        <a href="<?php echo e(route('prayers.show', $prayer)); ?>" class="text-xl font-semibold leading-6"><?php echo e($prayer->title); ?></a>
                        <div class="font-semibold mt-2">Minister: <?php echo e($prayer->author); ?> </div>
                        <div class="flex space-x-2 items-center text-sm pt-1">
                            <div> <?php echo e($prayer->created_at->diffForHumans()); ?></div>
                            <div>·</div>
                            <div> 156.9K views</div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
            <br>
            <?php echo e($prayers->links()); ?>



        </div>

        <!-- Sidebar -->
        <div class="lg:w-1/3 w-full">
            <div uk-sticky="media @m ; offset:80 ; bottom : true" class="card">


                <div class="border-b flex items-center justify-between  p-4">
                    <div>
                        <h2 class="text-lg font-semibold">Recent Prayer</h2>
                    </div>
                </div>

                <div class="p-3">

                    <?php $__currentLoopData = $recentprayers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prayer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="flex items-center space-x-4 rounded-md -mx-2 p-2 hover:bg-gray-50">
                        <a href="<?php echo e(route('prayers.show', $prayer)); ?>" iv class="text-base font-semibold capitalize"><?php echo e($prayer->title); ?>

                        </a>
                        <div class="flex-1">
                            
                            <div class="text-sm text-gray-500 mt-0.5"> <?php echo e($prayer->views); ?> Praying</div>
                        </div>
                        <a href="<?php echo e(route('prayers.show', $prayer)); ?>"
                            class="flex items-center justify-center h-8 px-3 rounded-md text-sm border font-semibold">Pray
                        </a>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </div>

                <a href="#" class="border-t block text-center py-2"> See all </a>

            </div>
        </div>


    </div>
    <?php endif; ?>


</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\unification\resources\views/prayers/index.blade.php ENDPATH**/ ?>