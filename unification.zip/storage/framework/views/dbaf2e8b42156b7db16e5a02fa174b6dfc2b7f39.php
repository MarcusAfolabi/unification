<?php $__env->startSection('title', 'Sub Convention Payment'); ?>
<?php $__env->startSection('main'); ?>
<div class="main_content">
    <div
        class="bg-gradient-to-tr flex from-blue-400 h-52 items-center justify-center lg:h-80 pb-10 relative to-blue-300 via-blue-400 w-full">

        <div class="text-center max-w-xl mx-auto z-10 relative px-5">
            <div class="lg:text-4xl text-2xl text-white font-semibold mb-3"> SUB - CONVENTION 2022 </div>
            <div class="text-white text-lg font-medium text-opacity-90"> Choose the appropriate level please.</div>
        </div>
    </div>

    


    <div class="mcontainer">
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.validation-errors','data' => ['class' => 'mb-4']] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('jet-validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'mb-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

        <div class="-mt-10 bg-blue max-w-2x1 mx-auto p-10 relative rounded-md shadow">
            <?php if(session('status')): ?>
            <p class="bg-green-500 text-white text-center border p-4 relative rounded-md uk-alert">
                <?php echo e(session('status')); ?></p>
            <?php endif; ?>
            <div class="grid md:grid-cols-2 md:gap-y-7 md:gap-x-6 gap-6">


                <div class="md:col-span-2 md:flex items-center justify-between">
                    <a href="https://flutterwave.com/pay/graduate_student"
                        class="button bg-blue-700 w-full md:w-auto md:mt-0 mt-4">
                        Gradudate N2,500</a>

                    <a href="https://flutterwave.com/pay/students_payment"
                        class="button bg-dark-700 w-full md:w-auto md:mt-0 mt-4">Undergraduate N1,500
                    </a>
                </div>
            </div>

        </div>

    </div>
</div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Unification\resources\views/convention/payment.blade.php ENDPATH**/ ?>