<?php $__env->startComponent('mail::message'); ?>
<center><a href="https://cnsunification.org">
    <img src="<?php echo e(asset('assets/images/isokan_logo.png')); ?>"
        alt="Cherubim and Seraphim Church Campus Fellowship logo">
</a><br>
</center>
# Dear

I welcome you all to the CHERUBIM AND SERAPHIM UNIFICATION CAMPUS FELLOWSHIP WEBSITE. It's a great privilege and
honour to have you here. The grace that brought you here will keep you.<br>

This website is solely for the edification of the saints, updates on the events concerning the fellowships under
this body and also dissemination of information about the body as a whole.<br>
I will beseech you all to abide by the rules and regulations set for the websites. There are many benefits to derive
from this website both spiritually and physically.e<br>
There are spiritual videos, audio and books you can download for your spiritual growth. We have daily prayer and
daily scripture exposition you can practise and also meditate on before you start your daily activity.<br>

For you to be partakers of the development of this website, you need to tell your fellow members and alumni to join
this train so that they can also benefit from all that you'll benefit from on this website.<br>
Once again, I welcome you to this website and I pray that the grace of God will continue to be sufficient for you.<br>

<?php $__env->startComponent('mail::button', ['url' => 'https://cnsunification.org/payment']); ?>
Proceed to Payment
<?php echo $__env->renderComponent(); ?>
Isokan ni ooo.<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\xampp\htdocs\Unification\resources\views/mail/welcome-mail.blade.php ENDPATH**/ ?>