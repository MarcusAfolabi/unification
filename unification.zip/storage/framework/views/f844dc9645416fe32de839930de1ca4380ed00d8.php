<?php $__env->startSection('title', 'Welcome'); ?>

<?php $__env->startSection('main'); ?>



<div class="main_content">
    <div class="mcontainer">

        <!--  Feeds  -->
        <div class="lg:flex lg:space-x-10">
            <div class="lg:w-3/4 lg:px-20 space-y-7">

                <!-- user story -->
                <div class="user_story grid md:grid-cols-5 grid-cols-3 gap-2 lg:-mx-20 relative">

                    <?php $__currentLoopData = $poststories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $poststory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('posts.show', $poststory)); ?>">
                        <div class="single_story">
                            <img src="<?php echo e(asset($poststory->image1)); ?>" alt="<?php echo e($poststory->postTitle); ?>">
                            <div class="story-avatar"> <img src="<?php echo e($poststory->user->profile_photo_url); ?>"
                                    alt="<?php echo e($poststory->postTitle); ?>"></div>
                            <div class="story-content">
                                <h4><?php echo e($poststory->user->name); ?> </h4>
                            </div>
                        </div>
                    </a>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <span class="absolute bg-white lg:flex items-center justify-center p-2 rounded-full
                            shadow-md text-xl w-9 z-10 uk-position-center-right -mr-4 hidden">
                        <i class="icon-feather-chevron-right"></i></span>

                </div>

                <!-- create post model redirect-->

                <div class="card lg:mx-0 p-4">
                    <a href="<?php echo e(route('posts.create')); ?>">
                        <div class="flex space-x-3">
                            <?php if(auth()->guard()->check()): ?>
                            <img src="<?php echo e(asset(auth()->user()->profile_photo_url)); ?>" class="w-10 h-10 rounded-full">
                            <input placeholder="What's Your Mind? <?php echo e(auth()->user()->lastname); ?>!"
                                class="bg-gray-100 hover:bg-gray-200 flex-1 h-10 px-6 rounded-full">
                            <?php endif; ?>
                            <?php if(auth()->guard()->guest()): ?>
                            <img src="<?php echo e(asset('assets/images/logo.png')); ?>" class="w-10 h-10 rounded-full">
                            <input placeholder="What's Your Mind?"
                                class="bg-gray-100 hover:bg-gray-200 flex-1 h-10 px-6 rounded-full">
                            <?php endif; ?>
                        </div>
                        <div class="grid grid-flow-col pt-3 -mx-1 -mb-1 font-semibold text-sm">
                            <div class="hover:bg-gray-100 flex items-center p-1.5 rounded-md cursor-pointer">
                                <svg class="bg-blue-100 h-9 mr-2 p-1.5 rounded-full text-blue-600 w-9 -my-0.5 hidden lg:block"
                                    data-tippy-placement="top" title="Tooltip" fill="none" stroke="currentColor"
                                    viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z">
                                    </path>
                                </svg>
                                Photo/Video
                            </div>
                            <div class="hover:bg-gray-100 flex items-center p-1.5 rounded-md cursor-pointer">
                                <svg class="bg-green-100 h-9 mr-2 p-1.5 rounded-full text-green-600 w-9 -my-0.5 hidden lg:block"
                                    uk-tooltip="title: Messages ; pos: bottom ;offset:7" fill="none"
                                    stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"
                                    title="" aria-expanded="false">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M18 9v3m0 0v3m0-3h3m-3 0h-3m-2-5a4 4 0 11-8 0 4 4 0 018 0zM3 20a6 6 0 0112 0v1H3v-1z">
                                    </path>
                                </svg>
                                Tag Friend
                            </div>
                            <div class="hover:bg-gray-100 flex items-center p-1.5 rounded-md cursor-pointer">
                                <svg class="bg-red-100 h-9 mr-2 p-1.5 rounded-full text-red-600 w-9 -my-0.5 hidden lg:block"
                                    fill="none" stroke="currentColor" viewBox="0 0 24 24"
                                    xmlns="http://www.w3.org/2000/svg">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M14.828 14.828a4 4 0 01-5.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z">
                                    </path>
                                </svg>
                                Fealing /Activity
                            </div>
                        </div>
                    </a>
                </div>
                <!--Facebook Live Stream-->
                <!--       <div class="card lg:mx-0 uk-animation-slide-bottom-small">-->
                <!--<iframe src="https://www.facebook.com/plugins/video.php?height=314&href=https%3A%2F%2Fweb.facebook.com%2Fisokancampusfellowship%2Fvideos%2F992460284753231%2F&show_text=false&width=560&t=0" width="586" height="321" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowfullscreen="true" allow="autoplay; clipboard-write; encrypted-media; picture-in-picture; web-share" allowFullScreen="true"></iframe>-->
                <!--       </div>-->
                <!--Youtube Videos-->
                <!--       <div class="card lg:mx-0 uk-animation-slide-bottom-small">-->
                <!--<iframe width="586" height="321" src="https://www.youtube.com/embed/8YcC2LC8bII" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>-->
                <!--       </div>-->
                <!--End Live Stream-->

                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card lg:mx-0 uk-animation-slide-bottom-small">

                    <!-- post header-->
                    <div class="flex justify-between items-center lg:p-4 p-2.5">
                        <div class="flex flex-1 items-center space-x-4">
                            <a href="">
                                <img src="<?php echo e($post->user->profile_photo_url); ?>"
                                    class="bg-gray-200 border border-white rounded-full w-10 h-10">
                            </a>
                            <div class="flex-1 font-semibold capitalize">
                                <a href="<?php echo e(route('posts.show', $post)); ?>" class="text-black dark:text-gray-100"><?php echo e($post->postTitle); ?> </a>
                                <div class="text-xs"> <?php echo e($post->user->name); ?>

                                    posted <?php echo e($post->created_at->diffForHumans()); ?> <ion-icon name="people">
                                    </ion-icon>
                                </div>
                            </div>
                        </div>
                        <div>
                            <a href="#"> <i
                                    class="icon-feather-more-horizontal text-2xl hover:bg-gray-200 rounded-full p-2 transition -mr-1 dark:hover:bg-gray-700"></i>
                            </a>
                            <div class="bg-white w-56 shadow-md mx-auto p-2 mt-12 rounded-md text-gray-500 hidden text-base border border-gray-100 dark:bg-gray-900 dark:text-gray-100 dark:border-gray-700"
                                uk-drop="mode: click;pos: bottom-right;animation: uk-animation-slide-bottom-small">

                                <ul class="space-y-1">
                                    <?php if(auth()->guard()->guest()): ?>

                                    <li>
                                        <div class="fb-share-button"
                                            data-href="https://web.facebook.com/isokancampusfellowship"
                                            data-layout="button" data-size="small"><a target="_blank"
                                                href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e(route('posts.show', $post)); ?>&amp;text=<?php echo e($post->postTitle); ?>&amp;src=sdkpreparse"
                                                class="flex items-center px-3 py-2 hover:bg-gray-200 hover:text-gray-800 rounded-md dark:hover:bg-gray-800">
                                                <i class="icon-brand-facebook-square"> </i> Share</a>
                                        </div>

                                    </li>
                                    <li>

                                        <a href="https://twitter.com/intent/tweet?url=<?php echo e(route('posts.show', $post)); ?>&amp;text=-<?php echo e($post->postTitle); ?>&amp;text=By <?php echo e($post->user->name); ?>"
                                            target="_blank"
                                            class="flex items-center px-3 py-2 hover:bg-gray-200 hover:text-gray-800 rounded-md dark:hover:bg-gray-800">
                                            <i class="icon-brand-twitter-square"> </i> Share</a>
                                    </li>
                                    <li>

                                        <a href="https://api.whatsapp.com/share?url=<?php echo e(route('posts.show', $post)); ?>"
                                            target="_blank"
                                            class="flex items-center px-3 py-2 hover:bg-gray-200 hover:text-gray-800 rounded-md dark:hover:bg-gray-800">
                                            <i class="icon-brand-whatsapp-square"> </i> Share</a>
                                    </li>
                                    <?php endif; ?>
                                    <?php if(auth()->guard()->check()): ?>
                                    <li>
                                        <div class="fb-share-button"
                                            data-href="https://web.facebook.com/isokancampusfellowship"
                                            data-layout="button" data-size="small"><a target="_blank"
                                                href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e(route('posts.show', $post)); ?>&amp;text=<?php echo e($post->postTitle); ?>&amp;src=sdkpreparse"
                                                class="flex items-center px-3 py-2 hover:bg-gray-200 hover:text-gray-800 rounded-md dark:hover:bg-gray-800">
                                                <i class="icon-brand-facebook-square"> </i> Share</a>
                                        </div>

                                    </li>
                                    <li>

                                        <a href="https://twitter.com/share?url=<?php echo e(route('posts.show', $post)); ?>&amp;text=-<?php echo e($post->postTitle); ?>&amp;text=By <?php echo e($post->user->name); ?>"
                                            target="_blank"
                                            class="flex items-center px-3 py-2 hover:bg-gray-200 hover:text-gray-800 rounded-md dark:hover:bg-gray-800">
                                            <i class="icon-brand-twitter-square"> </i> Share</a>
                                    </li>
                                    <li>

                                        <a href="https://whatsapp.com/share?url=<?php echo e(route('posts.show', $post)); ?>"
                                            target="_blank"
                                            class="flex items-center px-3 py-2 hover:bg-gray-200 hover:text-gray-800 rounded-md dark:hover:bg-gray-800">
                                            <i class="icon-brand-whatsapp-square"> </i> Share</a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(route('posts.edit', $post)); ?>"
                                            class="flex items-center px-3 py-2 hover:bg-gray-200 hover:text-gray-800 rounded-md dark:hover:bg-gray-800">
                                            <i class="uil-edit-alt mr-1"></i> Edit Post
                                        </a>
                                    </li>
                                    <li>
                                        <hr class="-mx-2 my-2 dark:border-gray-800">
                                    </li>
                                    <li>
                                        <a href=""
                                            class="flex items-center px-3 py-2 text-red-500 hover:bg-red-100 hover:text-red-500 rounded-md dark:hover:bg-red-600">
                                            <i class="uil-trash-alt mr-1"></i> Delete
                                        </a>
                                    </li>
                                    <?php endif; ?>

                                </ul>

                            </div>
                        </div>
                    </div>
                    <div class="p-2 pt-0 leading-6 line-clamp-2 mt-1">

                        <?php echo $post->fullDescription; ?>

                    </div>



                    <div uk-lightbox>
                        <div class="grid grid-cols-2 gap-2 px-5">

                            <a href="<?php echo e(asset($post->image)); ?>" class="col-span-2">
                                <img src="<?php echo e(asset($post->image)); ?>" alt="<?php echo e($post->postTitle); ?>"
                                    class="rounded-md w-full lg:h-76 object-cover">
                            </a>
                            <a href="<?php echo e(asset($post->image1)); ?>">
                                <img src="<?php echo e(asset($post->image1)); ?>" alt="<?php echo e($post->postTitle); ?>"
                                    class="rounded-md w-full h-full">
                            </a>
                            <a href="<?php echo e(asset($post->image2)); ?>" class="relative">
                                <img src="<?php echo e(asset($post->image2)); ?>" alt="<?php echo e($post->postTitle); ?>"
                                    class="rounded-md w-full h-full">
                                <div
                                    class="absolute bg-gray-900 bg-opacity-30 flex justify-center items-center text-white rounded-md inset-0 text-2xl">
                                </div>
                            </a>

                        </div>
                    </div>

                    <div class="p-4 space-y-3">

                        <div class="flex space-x-4 lg:font-bold">

                            <div class="fb-like" data-href="https://cnsunification.org/<?php echo e(route('posts.show', $post)); ?>"
                                data-width="" data-layout="button_count" data-action="like" data-size="small"
                                data-share="false">

                            </div>

                            <div class="fb-share-button" data-href="https://web.facebook.com/isokancampusfellowship"
                                data-layout="button" data-size="small"><a target="_blank"
                                    href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e(route('posts.show', $post)); ?>&amp;text=<?php echo e($post->postTitle); ?>&amp;src=sdkpreparse"
                                    class="flex items-center px-3 py-2 hover:bg-gray-200 hover:text-gray-800 rounded-md dark:hover:bg-gray-800">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"
                                        width="20" height="20" class="dark:text-gray-100">
                                        <path
                                            d="M15 8a3 3 0 10-2.977-2.63l-4.94 2.47a3 3 0 100 4.319l4.94 2.47a3 3 0 10.895-1.789l-4.94-2.47a3.027 3.027 0 000-.74l4.94-2.47C13.456 7.68 14.19 8 15 8z" />
                                    </svg>Share</a>
                            </div>

                        </div>



                    </div>

                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                
                <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card lg:mx-0 uk-animation-slide-bottom-small">
                    <!-- post header-->
                    <div class="flex justify-between items-center lg:p-4 p-2.5">
                        <div class="flex flex-1 items-center space-x-4">
                            <a href="<?php echo e(route('videos.show', $video->user->id)); ?>">
                                <img src="<?php echo e($video->user->profile_photo_url); ?>"
                                    class="bg-gray-200 border border-white rounded-full w-10 h-10">
                            </a>
                            <div class="flex-1 font-semibold capitalize ">
                                <a href="#" class="text-black dark:text-gray-100"> <?php echo e($video->title); ?> </a>
                                <div class="text-xs"> <?php echo e($video->user->name); ?>

                                    posted <?php echo e($video->created_at->diffForHumans()); ?> <ion-icon name="people">
                                    </ion-icon>
                                </div>
                            </div>
                        </div>
                        <div>
                            <a href="#"> <i
                                    class="icon-feather-more-horizontal text-2xl hover:bg-gray-200 rounded-full p-2 transition -mr-1 dark:hover:bg-gray-700"></i>
                            </a>
                            <div class="bg-white w-56 shadow-md mx-auto p-2 mt-12 rounded-md text-gray-500 hidden text-base border border-gray-100 dark:bg-gray-900 dark:text-gray-100 dark:border-gray-700"
                                uk-drop="mode: click;pos: bottom-right;animation: uk-animation-slide-bottom-small">

                                <ul class="space-y-1">

                                    <?php if(auth()->guard()->guest()): ?>
                                    <li>
                                        <a href="#"
                                            class="flex items-center px-3 py-2 hover:bg-gray-200 hover:text-gray-800 rounded-md dark:hover:bg-gray-800">
                                            <i class="uil-share-alt mr-1"></i> Share
                                        </a>
                                    </li>
                                    <?php endif; ?>
                                    <?php if(auth()->guard()->check()): ?>
                                    <li>
                                        <a href="#"
                                            class="flex items-center px-3 py-2 hover:bg-gray-200 hover:text-gray-800 rounded-md dark:hover:bg-gray-800">
                                            <i class="uil-share-alt mr-1"></i> Share
                                        </a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(route('videos.edit', $video)); ?>"
                                            class="flex items-center px-3 py-2 hover:bg-gray-200 hover:text-gray-800 rounded-md dark:hover:bg-gray-800">
                                            <i class="uil-edit-alt mr-1"></i> Edit Post
                                        </a>
                                    </li>
                                    <li>
                                        <hr class="-mx-2 my-2 dark:border-gray-800">
                                    </li>
                                    <li>
                                        <a href="<?php echo e(route('videos.destroy', $video->id)); ?>"
                                            class="flex items-center px-3 py-2 text-red-500 hover:bg-red-100 hover:text-red-500 rounded-md dark:hover:bg-red-600">
                                            <i class="uil-trash-alt mr-1"></i> Delete
                                        </a>
                                    </li>
                                    <?php endif; ?>

                                </ul>

                            </div>
                        </div>
                    </div>

                    <div class="w-full h-full">
                        <div class="embed-video rounded">
                            <iframe src="<?php echo e($video->url); ?>" frameborder="0" uk-video="automute: true; autoplay: false" allowfullscreen
                                uk-responsive></iframe>

                        </div>
                    </div>

                    <div class="p-4 space-y-3">

                        <div class="flex space-x-4 lg:font-bold">
                            <div class="fb-like" data-href="https://cnsunification.org/<?php echo e(route('posts.show', $post)); ?>"
                                data-width="" data-layout="button_count" data-action="like" data-size="small"
                                data-share="false">

                            </div>

                            <div class="fb-share-button" data-href="https://web.facebook.com/isokancampusfellowship"
                                data-layout="button" data-size="small"><a target="_blank"
                                    href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e(route('posts.show', $post)); ?>&amp;text=<?php echo e($post->postTitle); ?>&amp;src=sdkpreparse"
                                    class="flex items-center px-3 py-2 hover:bg-gray-200 hover:text-gray-800 rounded-md dark:hover:bg-gray-800">
                                    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor"
                                        width="20" height="20" class="dark:text-gray-100">
                                        <path
                                            d="M15 8a3 3 0 10-2.977-2.63l-4.94 2.47a3 3 0 100 4.319l4.94 2.47a3 3 0 10.895-1.789l-4.94-2.47a3.027 3.027 0 000-.74l4.94-2.47C13.456 7.68 14.19 8 15 8z" />
                                    </svg>Share</a>
                            </div>
                        </div>
                    </div>

                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
            <div class="lg:w-72 w-full">
                <a href="#">
                    <div class="bg-white mb-5 px-4 py-3 rounded-md shadow">
                        <h3 class="text-line-through font-semibold mb-1"> Daily Bible Verse </h3>
                        <div class="-mx-2 duration-300 flex hover:bg-gray-50 px-2 py-2 rounded-md">
                            <img src="<?php echo e(asset('assets/images/icons/bible-icon.png')); ?>" class="w-9 h-9 mr-3" alt="">
                            <p class="line-clamp-2 leading-6">
                            <div id="dailyVersesWrapper"></div>
                            <script async defer src="https://dailyverses.net/get/verse.js?language=niv"></script>
                            </p>
                        </div>
                    </div>
                </a>

                <div class="bg-white mb-5 px-4 py-3 rounded-md shadow">
                    <h3 class="text-line-through font-semibold mb-1"> Daily Prayer Chant </h3>
                    <?php $__currentLoopData = $sideprayers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sideprayer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="-mx-2 duration-300 flex hover:bg-gray-50 px-2 py-2 rounded-md">
                        <img src="<?php echo e(asset('assets/images/icons/dua-hands.png')); ?>" class="w-9 h-9 mr-3" alt="">
                        <p class="line-clamp-2 leading-6">
                            <a href="<?php echo e(route('prayers.show', $sideprayer)); ?>"><?php echo e($sideprayer->title); ?></a>
                        </p>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
                <br>
                    <h3 class="text-line-through font-semibold mb-1"> Suggested Audios - <a href="<?php echo e(route('audios.index')); ?>" class="hover:text-blue-600 hover:underline"> See All </a> </h3>
                <?php $__currentLoopData = $sideaudios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sideaudio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="bg-white mb-5 px-4 py-3 rounded-md shadow">
                    <h3 class="text-line-through font-semibold mb-1 leading-6 line-clamp-1 mt-1">
                        <?php echo e($sideaudio->title); ?> by <?php echo e($sideaudio->author); ?></h3>
                    <div class="-mx-2 duration-300 flex hover:bg-gray-50 px-2 py-2 rounded-md">
                        <img src="<?php echo e(asset($sideaudio->image)); ?>" class="w-9 h-9 mr-3" alt="">
                        <p class="line-clamp-2 leading-6">
                            <audio class="js-player">
                                <source src="<?php echo e($sideaudio->file); ?>" />
                            </audio>
                        </p>

                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <div class="bg-white mb-5 px-4 py-3 rounded-md shadow">
                    <h3 class="text-line-through font-semibold mb-1"> Suggested Products </h3>
                    <?php $__currentLoopData = $sideproducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sideproduct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('products.show', $sideproduct)); ?>">
                        <div class="-mx-2 duration-300 flex hover:bg-gray-50 px-2 py-2 rounded-md">
                            <img src="<?php echo e(asset($sideproduct->image)); ?>" class="w-9 h-9 mr-3" alt="">
                            <p class="line-clamp-2 leading-6 mt-1"> <strong> <?php echo e($sideproduct->name); ?> </strong> for
                                <strong> <?php echo e($sideproduct->currency); ?><?php echo e(number_format($sideproduct->price)); ?>

                                </strong>

                            </p>
                        </div>
                    </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <br>
                    <hr>
                <a href="<?php echo e(route('products.index')); ?>" class="hover:text-blue-600 hover:underline"> See All </a>
                </div>
                <div class="bg-white mb-5 px-4 py-3 rounded-md shadow">
                    <h3 class="text-line-through font-semibold mb-1"> Suggested Vacancies </h3>
                    <?php $__currentLoopData = $sidejobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sidejob): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('vacancies.show', $sidejob)); ?>">
                        <div class="-mx-2 duration-300 flex hover:bg-gray-50 px-2 py-2 rounded-md">
                            <img src="<?php echo e(asset($sidejob->image)); ?>" class="w-9 h-9 mr-3" alt="">
                            <p class="line-clamp-2 leading-6 mt-2"> <strong> <?php echo e($sidejob->position); ?> </strong> Salary of
                                <strong> <?php echo e($sidejob->currency); ?><?php echo e(number_format($sidejob->salary, 2)); ?>

                                </strong>

                            </p>
                        </div>
                    </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                     <br>
                    <hr>
                    <a href="<?php echo e(route('vacancies.index')); ?>" class="hover:text-blue-600 hover:underline"> See All </a>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', () => {
            const player = Plyr.setup('.js-player');
        });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Unification\resources\views/welcome.blade.php ENDPATH**/ ?>