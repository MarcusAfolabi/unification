<?php $__env->startSection('title', $product->name ); ?>
<?php $__env->startSection('description', $product->name); ?>
<?php $__env->startSection('keywords', 'selling product, buying product, items, amazon, shop, shopping, shoprite, justrite, ikeja mall, allen avenue mall,
ecommerce, facebook, facebook shop, shop, buyers, sellers, small business, enterprise'); ?>
<?php $__env->startSection('canonical', 'https://cnsunification.org/products'); ?>

<?php $__env->startSection('main'); ?>
<div id="fb-root"></div>
<script async defer crossorigin="anonymous"
    src="https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v13.0&appId=562231884526354&autoLogAppEvents=1"
    nonce="t3DkjUu0"></script>
<div class="main_content">
    <div class="mcontainer">

        <!--  Feeds  -->
        <div class="lg:flex lg:space-x-10">
            <div class="lg:w-3/4 lg:px-20 space-y-7">



                <div class="card lg:mx-0 uk-animation-slide-bottom-small">
                    <div class="flex justify-between items-center lg:p-4 p-2.5">
                        <div class="flex flex-1 items-center space-x-4">
                            <a href="<?php echo e(route('products.show', $product)); ?>">
                                <img src="<?php echo e(asset($product->user->profile_photo_url)); ?>"
                                    class="bg-gray-200 border border-white rounded-full w-10 h-10">
                            </a>
                            <div class="flex-1 font-semibold capitalize">
                                <a href="#" class="text-black"> <?php echo e($product->user->name); ?>

                                    <?php echo e($product->user->lastname); ?> </a>
                                <div class="text-gray-700 flex items-center space-x-2">
                                    <?php echo e($product->created_at->diffForHumans()); ?></div>
                            </div>
                        </div>
                        <div>
                            <a href="#"> <i
                                    class="icon-feather-more-horizontal text-2xl hover:bg-gray-200 rounded-full p-2 transition -mr-1 dark:hover:bg-gray-700"></i>
                            </a>
                            <div class="bg-white w-56 shadow-md mx-auto p-2 mt-12 rounded-md text-gray-500 hidden text-base border border-gray-100 dark:bg-gray-900 dark:text-gray-100 dark:border-gray-700"
                                uk-drop="mode: click;pos: bottom-right;animation: uk-animation-slide-bottom-small">

                                <ul class="space-y-1">

                                    <li>
                                        <div class="fb-share-button"
                                            data-href="https://web.facebook.com/isokancampusfellowship"
                                            data-layout="button" data-size="small"><a target="_blank"
                                                href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e(route('products.show', $product)); ?>&amp;text=<?php echo e($product->title); ?>&amp;src=sdkpreparse"
                                                class="flex items-center px-3 py-2 hover:bg-gray-200 hover:text-gray-800 rounded-md dark:hover:bg-gray-800">
                                                <i class="icon-brand-facebook-square"> </i> Share</a>
                                        </div>

                                    </li>
                                    <li>

                                        <a href="https://twitter.com/share?url=<?php echo e(route('products.show', $product)); ?>&amp;text=-<?php echo e($product->title); ?>&amp;text=By <?php echo e($product->user->name); ?>"
                                            target="_blank"
                                            class="flex items-center px-3 py-2 hover:bg-gray-200 hover:text-gray-800 rounded-md dark:hover:bg-gray-800">
                                            <i class="icon-brand-twitter-square"> </i> Share</a>
                                    </li>
                                    <li>

                                        <a href="https://api.whatsapp.com/share?url=<?php echo e(route('products.show', $product)); ?>"
                                            target="_blank"
                                            class="flex items-center px-3 py-2 hover:bg-gray-200 hover:text-gray-800 rounded-md dark:hover:bg-gray-800">
                                            <i class="icon-brand-whatsapp-square"> </i> Share</a>
                                    </li>
                                    <?php if(auth()->guard()->check()): ?>
                                    <li>
                                        <a href="<?php echo e(route('products.edit', $product)); ?>"
                                            class="flex items-center px-3 py-2 hover:bg-gray-200 hover:text-gray-800 rounded-md dark:hover:bg-gray-800">
                                            <i class="uil-edit-alt mr-1"></i> Edit Product
                                        </a>
                                    </li>

                                    <li>
                                        <hr class="-mx-2 my-2 dark:border-gray-800">
                                    </li>
                                    <li>
                                        <form action="<?php echo e(route('products.destroy', $product)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('delete'); ?>
                                            <button type="submit"
                                                onclick="return confirm('Hey, Are you sure about this?');">
                                                <span class="icon-feather-trash-2"></span> Delete</button>

                                        </form>
                                    </li>
                                    <?php endif; ?>
                                </ul>

                            </div>
                        </div>
                    </div>

                    <div uk-lightbox>
                        <a href="<?php echo e(asset($product->image1)); ?>">
                            <img src="<?php echo e(asset($product->image)); ?>" alt="<?php echo e($product->name); ?>"
                                class="max-h-96 w-full object-cover">
                        </a>
                    </div>

                    <div class="p-4 space-y-3 relative">
                        <div class="text-2xl font-semibold pt-2"> <?php echo e($product->name); ?></div>
                        <p> <?php echo $product->description; ?></p>

                        <div
                            class="top-3 absolute bg-gray-100 font-semibold px-3 py-1 right-3 rounded-full text text-sm">
                            <?php echo e($product->currency); ?><?php echo e(number_format($product->price)); ?>

                        </div>

                        <div class="flex space-x-3 items-center text-sm md:pt-3">
                            <div>Condition: <?php echo e($product->type); ?></div>
                            <div class="md:block hidden">·</div>
                            <div class="font-semibold text-yellow-500"> <?php echo e($product->stock); ?></div>
                            <div class="md:block hidden">·</div>
                            <div class="flex"> Brand: &nbsp;<span class="font-semibold text-yellow-500 mr-2">
                                    <?php echo e($product->brand); ?> </span> </div>
                        </div>

                        <hr>

                        <div class="grid grid-cols-2 gap-4 mb-5">

                            <a href="tel:<?php echo e($product->user->phoneNumber); ?>"
                                class="bg-gray-200 flex flex-1 font-semibold h-10 items-center justify-center px-4 rounded-md">
                                Call seller
                            </a>
                            <a href="mailto:<?php echo e($product->user->email); ?>"
                                class="bg-red-600 flex flex-1 font-semibold h-10 items-center justify-center px-4 rounded-md text-white">
                                Email Seller
                            </a>

                        </div>
                        <div class="fb-like"
                            data-href="https://cnsunification.org/<?php echo e(route('products.show', $product)); ?>" data-width=""
                            data-layout="button_count" data-action="like" data-size="small" data-share="false">

                            <br>
                            <a href="#" class="hover:text-blue-600 hover:underline"> Product Review </a>



                            <div class="fb-comments"
                                data-href="https://.cnsunification.org/<?php echo e(route('products.show', $product)); ?>"
                                data-width="" data-numposts="5"></div>

                        </div>

                    </div>
                </div>


            </div>
            <div class="lg:w-72 w-full">
                <div class="bg-white mb-5 px-4 py-3 rounded-md shadow">
                    <h3 class="text-line-through font-semibold mb-1"> Other Products </h3>
                    <?php $__currentLoopData = $sidepros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sidepro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="<?php echo e(route('products.show', $sidepro)); ?>">
                        <div class="-mx-2 duration-300 flex hover:bg-gray-50 px-2 py-2 rounded-md">
                            <img src="<?php echo e(asset($sidepro->image)); ?>" class="w-9 h-9 mr-3" alt="">
                            <p class="line-clamp-2 leading-6"> <strong> <?php echo e($sidepro->name); ?> </strong> for
                                <strong> <?php echo e($sidepro->currency); ?><?php echo e(number_format($sidepro->price)); ?> </strong>

                            </p>
                        </div>
                    </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
                <a href="<?php echo e(route('products.index')); ?>" class="hover:text-blue-600 hover:underline"> See All </a>
            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\unification\resources\views/products/show.blade.php ENDPATH**/ ?>