<a href="/">
    <img src="<?php echo e(asset('assets/images/favicon/ms-icon-150x150.png')); ?>">
</a>
<?php /**PATH C:\xampp\htdocs\Unification\resources\views/vendor/jetstream/components/authentication-card-logo.blade.php ENDPATH**/ ?>