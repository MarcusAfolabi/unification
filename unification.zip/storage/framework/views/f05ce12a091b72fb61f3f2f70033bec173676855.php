<?php $__env->startSection('title', 'Add Prayers'); ?>

<?php $__env->startSection('main'); ?>
    <div class="main_content">
        <div class="mcontainer">

            <!--  breadcrumb -->
            <div class="breadcrumb-area py-0">
                <div class="breadcrumb">
                    <ul class="m-0">
                        <li>
                            <a href="<?php echo e(route('prayers.index')); ?>">All Prayer/Bible Study</a>
                        </li>
                        <li class="active">
                            <a href="<?php echo e(route('prayers.create')); ?>">Create New Prayer/Bible Study </a>
                        </li>
                    </ul>
                </div>
            </div>

                <!-- create page-->
                <div class="max-w-2xl m-auto shadow-md rounded-md bg-white lg:mt-20">
                    <?php if(session('status')): ?>
                        <p class="bg-green-500 text-white text-center border p-4 relative rounded-md uk-alert">
                            <?php echo e(session('status')); ?></p>
                    <?php endif; ?>
                    <!-- form header -->
                    <div class="py-4 border-b flex  justify-between px-6">
                        <h3 class="text-lg font-semibold"> Create Prayer/Bible Study  </h3>
                        <div>

                        </div>
                    </div>


                    <!-- form body -->

                    <form method="POST" action="<?php echo e(route('prayers.store')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="p-10 space-y-7">
                            <div class="line">
                                <input class="line__input" id="title" name="title" type="text"
                                    onkeyup="this.setAttribute('value', this.value);" value="<?php echo e(old('title')); ?>"
                                    autocomplete="off">
                                <span for="title" class="line__placeholder"> Title </span>
                            </div>
                            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p style="color: red; "><?php echo e($message); ?> </p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <div class="line">
                                <input class="line__input" id="author" name="author" type="text"
                                    onkeyup="this.setAttribute('value', this.value);" value="<?php echo e(old('author')); ?>"
                                    autocomplete="off">
                                <span for="title" class="line__placeholder"> Anchor/Author </span>
                            </div>
                            <?php $__errorArgs = ['author'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p style="color: red; "><?php echo e($message); ?> </p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <div class="col-span-2">
                                <label> Category </label>
                                <select id="category" name="category" class="selectpicker with-border">
                                    <option value="<?php echo e(old('currency')); ?>"> <?php echo e(old('category')); ?> </option>
                                    <option value="Bible Study"> Bible Study </option>
                                    <option value="Daily Prayer"> Daily Prayer </option>
                                </select>
                            </div>
                            <label>Date to Publish</label>
                            <div class="line">
                                <input class="line__input" id="publication" name="publication" type="date"
                                    onkeyup="this.setAttribute('value', this.value);" value="<?php echo e(old('publication')); ?>"
                                    autocomplete="off">
                                <span for="publication" class="line__placeholder">  </span>
                            </div>
                            <?php $__errorArgs = ['publication'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p style="color: red; "><?php echo e($message); ?> </p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p style="color: red; "><?php echo e($message); ?> </p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            <div class="form-group">
                                <textarea name="content" id="content" placeholder="Prayer/Bible Content" rows="5" cols="30">
                            <?php echo e(old('content')); ?></textarea>

                        </div>
                        </div>

                        <!-- form footer -->
                        <div class="border-t flex justify-between lg:space-x-10 p-7 bg-gray-50 rounded-b-md">
                            <p class="text-sm leading-6"> Your Daily Prayer or Daily Bible Study Is Subject to Review and Proof-reading. Ensure To Be
                                Accurate And Concise. </p>
                            <button class="button dark" type="submit">POST</button>
                        </div>

                    </form>


                </div>
            </div>
        </div>

        <script src="https://cdn.ckeditor.com/ckeditor5/32.0.0/classic/ckeditor.js"></script>
        <script>
            ClassicEditor
                .create(document.querySelector('#content'))
                .then(content => {
                    console.log(content);
                })
                .catch(error => {
                    console.error(error);
                });
        </script>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\unification\resources\views/prayers/create.blade.php ENDPATH**/ ?>