<?php $__env->startSection('title', $video->title); ?>
<?php $__env->startSection('description', 'These are available videos from Unification Campus Fellowship'); ?>
<?php $__env->startSection('keywords', 'video, youtube, training, coaching, seminar, empowerment, workshop, small business, job offer, training, empowerment program, federal programs'); ?>
<?php $__env->startSection('canonical', 'https://cnsunification.org/videos'); ?>

<?php $__env->startSection('main'); ?>
<div id="fb-root"></div>
    <script async defer crossorigin="anonymous"
        src="https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v13.0&appId=562231884526354&autoLogAppEvents=1"
        nonce="t3DkjUu0"></script>
    <div class="main_content">
        <div class="mcontainer">

            <div class="lg:flex lg:space-x-10">

                <div class="lg:w-3/4">

                    <div class="embed-video rounded">
                        <iframe src="<?php echo e($video->url); ?>" frameborder="0" uk-video="automute: true" allowfullscreen
                            uk-responsive></iframe>

                    </div>

                    <div class="py-5 space-y-4">

                        <div>
                            <h1 class="text-2xl font-semibold line-clamp-1"> <?php echo e($video->title); ?> </h1>
                            <p> <?php echo e($video->views); ?> views </p>
                        </div>

                        <div class="md:flex items-center justify-between">
                            <a href="#" class="flex items-center space-x-3">
                                <img src="<?php echo e(asset($video->user->name)); ?>" alt="" class="w-10 rounded-full">
                                <div class="">
                                    <div class="text-base font-semibold"> <?php echo e($video->user->name); ?> </div>
                                    <div class="text-xs"> Published on <?php echo e($video->created_at->diffForHumans()); ?>

                                    </div>
                                </div>
                            </a>
                            <div class="flex items-center space-x-3 md:pt-0 pt-2">
                                <div class="like-btn" uk-tooltip="Unlike it">
                                    <i class="uil-thumbs-down"></i>
                                    <span class="likes">16</span>
                                </div>
                                <div class="flex h-2 w-36 bg-gray-200 rounded-lg overflow-hidden">
                                    <div class="w-2/3 bg-gradient-to-br from-purple-400 to-blue-400 h-4"></div>
                                </div>
                                <div class="like-btn" uk-tooltip="I like it">
                                    <i class="uil-thumbs-up"></i>
                                    <span class="likes">21</span>
                                </div>
                            </div>
                        </div>

                        <div class="text-lg font-semibold pt-2"> Description </div>
                        <?php echo $video->content; ?>

                        <hr>

                        <div class="my-5">

                            <div class="fb-comments"
                            data-href="https://.cnsunification.org/<?php echo e(route('posts.show', $video)); ?>"
                            data-width="" data-numposts="5"></div>


                        </div>

                    </div>


                </div>

                <!-- sidebar -->
                <div class="lg:w-1/4 w-full">

                    <h3 class="text-xl font-bold mb-2"> Related Videos </h3>

                    <?php $__currentLoopData = $sidevideos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sidevideo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="py-2 relative">
                            <a href="<?php echo e(route('videos.show', $sidevideo)); ?>"
                                class="w-full h-32 overflow-hidden rounded-lg relative shadow-sm flex-shrink-0 block">
                                <img src="<?php echo e(asset($sidevideo->image)); ?>" alt="<?php echo e($sidevideo->title); ?>"
                                    class="w-full h-full absolute inset-0 object-cover">
                                <img src="<?php echo e(asset('assets/images/icon-play.svg')); ?>" class="w-12 h-12 uk-position-center"
                                    alt="<?php echo e($sidevideo->title); ?>">
                                <span
                                    class="absolute bg-black bg-opacity-60 bottom-1 font-semibold px-1.5 py-0.5 right-1 rounded text-white text-xs">
                                </span>
                            </a>
                            <div class="flex-1 pt-3 relative">
                                <a href="<?php echo e(route('videos.show', $sidevideo)); ?>" class="line-clamp-2 font-semibold">
                                    <?php echo e($sidevideo->title); ?></a>
                                <div class="flex space-x-2 items-center text-sm pt-1">
                                    <div> <?php echo e($sidevideo->created_at->diffForHumans()); ?></div>
                                    <div>·</div>
                                    <div> <?php echo e($sidevideo->views); ?> views</div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                </div>

            </div>


        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\unification\resources\views/videos/video.blade.php ENDPATH**/ ?>