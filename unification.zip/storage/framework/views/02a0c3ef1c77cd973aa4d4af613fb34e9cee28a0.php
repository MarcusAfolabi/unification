<a href="/">
    <img src="<?php echo e(asset('assets/images/favicon/android-icon-48x48.png')); ?>">
</a>
<?php /**PATH C:\xampp\htdocs\Unification\resources\views/vendor/jetstream/components/application-mark.blade.php ENDPATH**/ ?>