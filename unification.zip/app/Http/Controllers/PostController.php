<?php

namespace App\Http\Controllers;

use App\Models\Post;
// use App\Models\User;
use App\Models\User;
use App\Models\Product;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;
use App\Notifications\NewPostNotification;
use Illuminate\Support\Facades\Notification;
// use App\Notifications\NewPostNotification;
// use Illuminate\Support\Facades\Notification;

class PostController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */

    public function __construct()
    {
        $this->middleware('auth')->except(['show']);
    }
    public function index(Request $request)
    {
        if ($request->search) {
            $posts = Post::where('postTitle', 'like', '%' . $request->search . '%')
                ->orWhere('fullDescription', 'like', '%' . $request->search . '%')->latest()->paginate(40);
        } else {
            $posts = Post::latest()->paginate(40);
        }

        $sideposts = Post::all()->take(5);
        $sideproducts = Product::all()->take(5);

        return view('posts.index', compact('posts','sideposts','sideproducts'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('posts.create');

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $user= User::latest()->get();

        $request->validate([
            "postTitle" => 'required|unique:posts|max:255',
            "image" => 'required |image|mimes:jpeg,png,jpg,gif,svg,mp3,mp4|max:2048',
            "image1" => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            "image2" => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            "postCategories" => 'required',
            "fullDescription" => 'required'
        ]);
        $postTitle = $request->input('postTitle');
        $postCategories = $request->input('postCategories');
        $slug = Str::slug($postTitle, '-');
        $user_id = Auth::user()->id;
        $fullDescription = $request->input('fullDescription');

        // save single image
        $image = 'storage/' . $request->file('image')->store('postImages', 'public');
        $image1 = 'storage/' . $request->file('image1')->store('postImages', 'public');
        $image2 = 'storage/' . $request->file('image2')->store('postImages', 'public');

        $post = new Post();
        $post->postTitle = $postTitle;
        $post->slug = $slug;
        $post->user_id = $user_id;
        $post->postCategories = $postCategories;
        $post->fullDescription = $fullDescription;
        $post->image = $image;
        $post->image1 = $image1;
        $post->image2 = $image2;

        $post->save();
        Notification::send($user, new NewPostNotification($post));
        return redirect()->back()->with('status', 'Post Created Successfully. We ensure it edify the body of Christ before we publish');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Post  $post
     * @return \Illuminate\Http\Response
     */
    public function show(Post $post)
    {
        DB::table('posts')->increment('views');
        $timelineposts = Post::all();
        $tagposts = Post::latest()->take(5)->get();
        $sideposts = Post::all();
        $relatedposts = Post::where('id', '!=', $post->id)->latest()->take(5)->get();
        return view('posts.post', compact('post','relatedposts', 'sideposts', 'tagposts', 'timelineposts'));

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Post  $post
     * @return \Illuminate\Http\Response
     */
    public function edit(Post $post)
    {

        // if (auth()->user()->id !== $post->user_id) {
        //     abort(403);
        //     }
        // if (auth()->user()->isAdmin()){
        // return view('posts.edit', compact('post'));

        // }
        // if (auth()->user()->id === $post->user_id) {

        // }
        return view('posts.edit', compact('post'));

    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Post  $post
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Post $post)
    {
        // if (auth()->user()->id !== $post->user_id) {
        //     abort(403); //forbiden
        // }
        $request->validate([
            "postTitle" => 'required|max:255',
            "image" => 'required | image|mimes:jpeg,png,jpg,gif,svg,mp3,mp4|max:10048',
            "postCategories" => 'required',
            "fullDescription" => 'required'
        ]);
        $postTitle = $request->input('postTitle');
        $postCategories = $request->input('postCategories');
        $slug = Str::slug($postTitle, '-');
        $fullDescription = $request->input('fullDescription');

        $image = 'storage/' . $request->file('image')->store('postImages', 'public');
        $image1 = 'storage/' . $request->file('image1')->store('postImages', 'public');
        $image2 = 'storage/' . $request->file('image2')->store('postImages', 'public');

        $post->postTitle = $postTitle;
        $post->slug = $slug;
        $post->postCategories = $postCategories;
        $post->fullDescription = $fullDescription;
        $post->image = $image;
        $post->image1 = $image1;
        $post->image2 = $image2;

        $post->save();


        return redirect(route('posts.index'))->with('status', 'Post Updated Successfully. We ensure it edify the body of Christ before we publish');

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Post  $post
     * @return \Illuminate\Http\Response
     */
    public function status($id)
    {
        $post = Post::select('status')->where('id','=',$id)->first();

        if($post->status == '1')
        {
            $status = '0';
        }else{
            $status = '1';
        }

        $values = array('status' => $status);
        Post::where('id', $id)->update($values);

        return redirect()->back()->with('status', 'Status Updated');


    }

     public function destroy(Post $post)
    {

        $post->delete();
        return redirect()->back()->with('status', 'Post Delete Successfully.');
    }
}
