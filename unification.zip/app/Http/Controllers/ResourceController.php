<?php

namespace App\Http\Controllers;

use App\Models\Post;
use App\Models\User;
use App\Models\Product;
use App\Models\Resource;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
// use App\Notifications\NewPostNotification;
// use Illuminate\Support\Facades\Notification;

class ResourceController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function index()
    {
        $sideposts = Post::all()->take(5);
        $sideproducts = Product::all()->take(5);

        $resources = Resource::latest()->paginate(40);
        
        return view('resource.index', compact('resources', 'sideproducts', 'sideposts'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $role = Auth::user()->role;

        if($role == 'admin')
        {
            return view('resource.create');
        }
        else{
            abort(403);
        }
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {  
        //  $user= User::all();
        
        $request->validate([
            "name" => 'required',
            "file" => 'required',
        ]);
        $name = $request->input('name');
        $slug = Str::slug($name, '-');
        $user_id = Auth::user()->id;
        $file = 'storage/' . $request->file('file')->store('resourcesFile', 'public');

        $resource = new Resource();
        $resource->name = $name;
        $resource->slug = $slug;
        $resource->user_id = $user_id;
        $resource->file = $file;
        $resource->save();
        // Notification::send($user, new NewPostNotification($resource)); 
       return redirect(route('resource.index'))->with('status', 'File Added Successfully');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Resource  $resource
     * @return \Illuminate\Http\Response
     */
    public function show(Resource $resource)
    {
        return view('resource.show', compact('resource'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Resource  $resource
     * @return \Illuminate\Http\Response
     */
    public function edit(Resource $resource)
    {
        return view('resource.edit', compact('resource'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Resource  $resource
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Resource $resource)
    {
        $request->validate([
            "name" => 'required',
            "file" => 'required',
        ]);
        $name = $request->input('name');
        $slug = Str::slug($name, '-');
        // $user_id = Auth::user()->id;
        $file = 'storage/' . $request->file('file')->store('resourcesFile', 'public');

        // $resource = new Resource();
        $resource->name = $name;
        $resource->slug = $slug;
        // $resource->user_id = $user_id;
        $resource->file = $file;
        $resource->save();
        return redirect(route('resource.index'))->with('status', 'File Updated Successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Resource  $resource
     * @return \Illuminate\Http\Response
     */
    public function destroy(Resource $resource)
    {
        $resource->delete();
        return redirect()->back()->with('status', 'File Deleted Successfully');
    }
}
