@extends('layouts.main')
@section('title', 'Membership Login')
@section('main')
<script src="https://www.google.com/recaptcha/api.js?render={{ config('services.recaptcha.site_key') }}"></script>

<div class="lg:flex max-w-5xl min-h-screen mx-auto p-6 py-10">
    <div class="flex flex-col items-center lg: lg:flex-row lg:space-x-10">
        <br>
        <br>
        <div class="lg:mb-12 flex-1 lg:text-left text-center">
            <img src="{{ asset('assets/images/favicon/ms-icon-310x310.png') }}" alt="Unification Campus Fellowship"
                class="lg:mx-0 lg:w-52 mx-auto w-40">

        </div>
        <div class="lg:mb-0 lg:w-96 md:w-1/2 sm:w-2/3 mt-10 w-full">
            <br>
            <br>
            <x-jet-validation-errors class="mb-4" />

            <form method="POST" action="{{ route('login') }}"
                class="p-6 space-y-4 relative bg-white shadow-lg rounded-lg">
                @csrf
                <input type="email" id="email" name="email" placeholder="Email" class="with-border" required
                    autofocus />

                <input type="password" id="password" name="password" placeholder="Password" class="with-border" required
                    autocomplete="current-password" />

                <div class="checkbox">
                    <input type="checkbox" id="remember_me" name="remember">
                    <label for="remember_me"><span class="checkbox-icon"></span>Remember me
                    </label>
                </div>
                <button type="submit" class="bg-blue-600 font-semibold p-3 rounded-md text-center text-white w-full">
                    Log In
                </button>
                <a href="{{ route('password.request') }}" class="text-blue-500 text-center block"> Forgot Password? </a>
                <hr class="pb-3.5">
                <div class="flex">
                    <a href="{{route('register')}}" type="button"
                        class="bg-red-600 hover:bg-green-500 hover:text-white font-semibold py-3 px-5 rounded-md text-center text-white mx-auto">
                        New Member?
                    </a>
                </div>
            </form>

            <div class="mt-8 text-center text-sm"> <a href="{{ route('login') }}"
                    class="font-semibold hover:underline">Remember your creator, in the days of your youth</div>
        </div>

    </div>
</div>
@endsection