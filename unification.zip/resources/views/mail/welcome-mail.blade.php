@component('mail::message')
<center><a href="https://cnsunification.org">
    <img src="{{ asset('assets/images/isokan_logo.png') }}"
        alt="Cherubim and Seraphim Church Campus Fellowship logo">
</a><br>
</center>
# Dear

I welcome you to the CHERUBIM AND SERAPHIM UNIFICATION CAMPUS FELLOWSHIP WEBSITE. It's a great privilege and
honour to have you here. The grace that brought you here will keep you.<br>

This website is solely for the edification of the saints, updates on the events concerning the fellowships under
this body and also dissemination of information about the body as a whole.<br>
I will beseech you all to abide by the rules and regulations set for the websites. There are many benefits to derive
from this website both spiritually and physically.<br>
There are spiritual videos, audio and books you can download for your spiritual growth. We have daily prayer and
daily scripture exposition you can practise and also meditate on before you start your daily activity.<br>

For you to be partakers of the development of this website, you need to tell your fellow members and alumni to join
this train so that they can also benefit from all that you'll benefit from on this website.<br>
Once again, I welcome you to this website and I pray that the grace of God will continue to be sufficient for you.<br>

@component('mail::button', ['url' => 'https://cnsunification.org/payment'])
Proceed to Payment
@endcomponent
Isokan ni ooo! 🤗 <br>
{{ config('app.name') }}
@endcomponent
